# Policy LLM Fine-Tuning with LoRA (Polyglot-ko-1.3B)

This project fine-tunes a Korean LLM on national science and technology policy using the LoRA method. The base model is polyglot-ko-1.3b by EleutherAI.

## Directory Structure
- `src/`: Training, evaluation, and configuration scripts
- `data/`: Raw and processed datasets
- `outputs/`: Fine-tuned model adapters and output results
- `notebooks/`: Experimental analysis notebooks

## Requirements
See `requirements.txt` for dependencies.
